//
//  MtkDriverController.hpp
//  SimpleMtkWlan
//
//  Created by laobamac (王孝慈) on 2026/4/27.
//  Copyright © 2026 laobamac (王孝慈). All rights reserved.
//

/*
* Copyright (C) 2020  钟先耀
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/

#ifndef MtkDriverController_h
#define MtkDriverController_h

class MtkDriverController {
    
public:
    
    virtual void clearScanningFlags() = 0;
    
    virtual IOReturn setMulticastList(IOEthernetAddress *addr, int count) = 0;
};

#endif /* MtkDriverController_h */
